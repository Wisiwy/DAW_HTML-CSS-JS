//Redireccion de paginas
var btnPedido = document.getElementById('btn_hacerPedido');
//btnPedido.addEventListener('click', redireccionMenu());

function redireccionMenu(){
    window.location.href = '../views/hamburgueseria.html'
}


//recoger los pedidos antiguos de variable de sesion. 
var btnAntiguos = document.getElementById('btn_antiguos');